# django-routes-search

[![PyPI - Version](https://img.shields.io/pypi/v/django-routes-search.svg)](https://pypi.org/project/django-routes-search)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/django-routes-search.svg)](https://pypi.org/project/django-routes-search)

-----

**Table of Contents**

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install django-routes-search
```

## License

`django-routes-search` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
